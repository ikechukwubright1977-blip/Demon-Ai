# DEMON AI Android starter

This is the first DEMON Android app: a dark-themed chat interface that calls an OpenAI-compatible Chat Completions endpoint. It does not include an AI model locally yet. Internet access and a valid API endpoint/model/API key are needed for AI answers.

## Build APK using GitHub Actions (phone-friendly route)
1. Create a GitHub repository named `demon-ai`.
2. Upload all files in this folder to the repository root (including `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build DEMON APK** and tap **Run workflow** (or push to `main`).
5. Open the completed workflow run and download the `DEMON-debug-apk` artifact. Extract it to get `app-debug.apk`.
6. On Android, tap the APK and allow installation from that source if Android prompts you. Only install APKs you built or trust.

## Configure AI
Open DEMON > SETTINGS. Enter a compatible endpoint, model name, and API key. Default values target the OpenAI Chat Completions API and `gpt-4o-mini`; API access is not included and may cost money. For production, do not distribute a shared API key inside the app; use a secured backend proxy instead.

## Notes
- Package: `com.kam.demon`
- Version: 1.0
- This starter does not yet support offline inference, voice, long-term conversation history, or secure server-side API key management.
