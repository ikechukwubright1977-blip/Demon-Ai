package com.kam.demon;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(9,9,13), PANEL = Color.rgb(22,22,30), RED = Color.rgb(255,59,48), WHITE = Color.WHITE, MUTED = Color.rgb(175,175,190);
    private LinearLayout root, messages;
    private ScrollView scroll;
    private EditText input;
    private SharedPreferences prefs;
    private Button sendButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("demon_settings", MODE_PRIVATE);
        buildUi();
        addMessage("DEMON", "I'm DEMON, your personal AI assistant. Add your AI API key using Settings to enable online answers. Your key is stored on this device.", false);
    }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setPadding(dp(16), dp(12), dp(16), dp(12));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("DEMON", 27, WHITE, true); TextView subtitle = text("PERSONAL AI ASSISTANT", 10, RED, true);
        titles.addView(title); titles.addView(subtitle); header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("SETTINGS", PANEL, WHITE); settings.setOnClickListener(v -> settingsDialog()); header.addView(settings);
        root.addView(header);
        View line = new View(this); line.setBackgroundColor(Color.rgb(55,35,42)); LinearLayout.LayoutParams lpLine = new LinearLayout.LayoutParams(-1, dp(1)); lpLine.topMargin = dp(12); lpLine.bottomMargin = dp(10); root.addView(line, lpLine);
        scroll = new ScrollView(this); scroll.setFillViewport(true); messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(0, dp(4), 0, dp(8)); scroll.addView(messages); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout composer = new LinearLayout(this); composer.setGravity(Gravity.CENTER_VERTICAL); composer.setOrientation(LinearLayout.HORIZONTAL); composer.setPadding(0, dp(10), 0, 0);
        input = new EditText(this); input.setSingleLine(false); input.setMinLines(1); input.setMaxLines(4); input.setTextColor(WHITE); input.setHintTextColor(MUTED); input.setHint("Message DEMON..."); input.setTextSize(15); input.setPadding(dp(14), dp(10), dp(14), dp(10)); input.setBackground(roundBg(PANEL, 18)); composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        sendButton = button("SEND", RED, WHITE); LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(-2, dp(48)); sendLp.leftMargin = dp(8); composer.addView(sendButton, sendLp); sendButton.setOnClickListener(v -> sendMessage());
        root.addView(composer); setContentView(root);
    }

    private void sendMessage() {
        String prompt = input.getText().toString().trim(); if (prompt.isEmpty()) return;
        input.setText(""); ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
        addMessage("YOU", prompt, true);
        String key = prefs.getString("api_key", ""); String endpoint = prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions"); String model = prefs.getString("model", "gpt-4o-mini");
        if (key.isEmpty()) { addMessage("DEMON", "Online AI is not connected yet. Tap SETTINGS, enter your compatible AI API endpoint, model name, and API key, then try again. API usage may cost money.", false); return; }
        sendButton.setEnabled(false); sendButton.setText("...");
        addMessage("DEMON", "Thinking...", false);
        new Thread(() -> {
            String answer;
            try { answer = requestAi(endpoint, model, key, prompt); }
            catch (Exception e) { answer = "I couldn't reach the AI service. Check your internet connection, endpoint, model name, and API key. Details: " + e.getMessage(); }
            final String result = answer;
            runOnUiThread(() -> { int n = messages.getChildCount(); if (n > 0) messages.removeViewAt(n - 1); addMessage("DEMON", result, false); sendButton.setEnabled(true); sendButton.setText("SEND"); });
        }).start();
    }

    private String requestAi(String endpoint, String model, String key, String prompt) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(endpoint).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(45000); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Authorization", "Bearer " + key);
        JSONObject body = new JSONObject(); body.put("model", model); JSONArray msgs = new JSONArray();
        JSONObject system = new JSONObject(); system.put("role", "system"); system.put("content", "You are DEMON, a helpful personal AI assistant. Be clear, practical, and honest."); msgs.put(system);
        JSONObject user = new JSONObject(); user.put("role", "user"); user.put("content", prompt); msgs.put(user); body.put("messages", msgs); body.put("temperature", 0.7);
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes("UTF-8")); }
        int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder out = new StringBuilder(); try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"))) { String s; while ((s = br.readLine()) != null) out.append(s); }
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + out);
        JSONObject json = new JSONObject(out.toString()); return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
    }

    private void settingsDialog() {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(20), dp(8), dp(20), dp(2)); form.setBackgroundColor(PANEL);
        EditText endpoint = field("API endpoint", prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions"), false); EditText model = field("Model name", prefs.getString("model", "gpt-4o-mini"), false); EditText key = field("API key", prefs.getString("api_key", ""), true);
        form.addView(endpoint); form.addView(model); form.addView(key);
        new AlertDialog.Builder(this).setTitle("DEMON Settings").setView(form).setPositiveButton("SAVE", (d,w) -> { prefs.edit().putString("endpoint", endpoint.getText().toString().trim()).putString("model", model.getText().toString().trim()).putString("api_key", key.getText().toString().trim()).apply(); Toast.makeText(this, "Settings saved on this device", Toast.LENGTH_SHORT).show(); }).setNegativeButton("CANCEL", null).show();
    }

    private EditText field(String hint, String value, boolean secret) { EditText e = new EditText(this); e.setHint(hint); e.setText(value); e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setSingleLine(true); e.setPadding(dp(10), dp(8), dp(10), dp(8)); if(secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(8); e.setLayoutParams(p); return e; }
    private void addMessage(String who, String content, boolean user) { LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(13), dp(10), dp(13), dp(10)); card.setBackground(roundBg(user ? Color.rgb(50,25,30) : PANEL, 14)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(user ? (int)(getResources().getDisplayMetrics().widthPixels * .78) : -1, -2); p.gravity = user ? Gravity.RIGHT : Gravity.LEFT; p.topMargin = dp(6); p.bottomMargin = dp(6); TextView label = text(who, 10, user ? RED : MUTED, true); TextView body = text(content, 15, WHITE, false); body.setTextIsSelectable(true); card.addView(label); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = dp(4); card.addView(body, bp); messages.addView(card, p); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN)); }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private Button button(String s, int bg, int fg) { Button b = new Button(this); b.setText(s); b.setTextSize(11); b.setTextColor(fg); b.setAllCaps(false); b.setBackground(roundBg(bg, 14)); return b; }
    private android.graphics.drawable.GradientDrawable roundBg(int color, int radius) { android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
